__author__ = "Nadav"  # with teamwork of AI.

import threading
from classes import Func, CustomLogger
import pygame
import tkinter as tk
from tkinter import messagebox

WINDOW_WIDTH = 1000
WINDOW_HEIGHT = 700
PANEL_WIDTH = 200
SIDE_PANEL_WIDTH = 180
BOARD_WIDTH = WINDOW_WIDTH - PANEL_WIDTH - SIDE_PANEL_WIDTH
BOARD_HEIGHT = WINDOW_HEIGHT
BOARD_INSET = 10
FPS = 60

WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
GREEN = (0, 200, 0)
BLACK = (0, 0, 0)
BG = (150, 200, 255)
PANEL_GREEN = (102, 200, 200)
GRAY = (200, 200, 200)
SEMI_BG = (0, 0, 0, 150)

HIGHLIGHT_PADDING = 10


class Dice:
    SIZE = 60
    PIP_RADIUS = 7
    OFFSETS = {  # points drawing
        1: [(0, 0)],
        2: [(-1, -1), (1, 1)],
        3: [(-1, -1), (0, 0), (1, 1)],
        4: [(-1, -1), (-1, 1), (1, -1), (1, 1)],
        5: [(-1, -1), (-1, 1), (0, 0), (1, -1), (1, 1)],
        6: [(-1, -1), (-1, 0), (-1, 1), (1, -1), (1, 0), (1, 1)],
    }

    def __init__(self):
        self.values = [0, 0]

    def draw(self, surf, x, y): # I greatly dislike making a front-hand. Ai work at this func.
        for i, v in enumerate(self.values):
            r = pygame.Rect(x + i * (Dice.SIZE + 12), y, Dice.SIZE, Dice.SIZE)
            pygame.draw.rect(surf, WHITE, r)
            pygame.draw.rect(surf, BLACK, r, 2)
            if 1 <= v <= 6:
                cx, cy = r.center
                step = Dice.SIZE // 4
                for ox, oy in Dice.OFFSETS[v]:
                    pygame.draw.circle(surf, BLACK,
                                       (cx + ox * step, cy + oy * step),
                                       Dice.PIP_RADIUS)


class Button:
    def __init__(self, rect, text, command):
        self.font_med = pygame.font.SysFont(None, 32)
        self.font_sm = pygame.font.SysFont(None, 24)

        self.rect = pygame.Rect(rect)
        self.text = text
        self.command = command

    def draw(self, surf): # I greatly dislike making front-hand. Ai work at this func.
        pygame.draw.rect(surf, GRAY, self.rect)
        pygame.draw.rect(surf, BLACK, self.rect, 2)
        txt = self.font_sm.render(self.text, True, BLACK)  # antialias = better looking
        surf.blit(txt, txt.get_rect(center=self.rect.center))

    def handle(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
            self.command()
            return True
        return False


class Checker:
    R = 20  # will be overridden in Game.__init__

    def __init__(self, pt, color):
        self.pt = pt
        self.color = color

    def draw(self, surf, x, y):
        pygame.draw.circle(surf, self.color, (int(x), int(y)), Checker.R)
        pygame.draw.circle(surf, BLACK, (int(x), int(y)), Checker.R, 2)


class Game:
    def __init__(self, player_color, player_username, opponent_username, PROTO, turn, logging_level):

        pygame.init()

        self.font_med = pygame.font.SysFont(None, 32)
        self.font_sm = pygame.font.SysFont(None, 24)

        b0 = pygame.image.load('Images/board.png')
        dict_of_colors = {"White": WHITE, "Yellow": YELLOW}
        self.color = player_color
        self.player_color = dict_of_colors[self.color]  # used for drawing
        self.flipped = (self.color == "Yellow")  # Yellow player sees board flipped
        self.player_username = player_username
        self.opponent_username = opponent_username
        self.PROTO = PROTO

        self.logging_level = logging_level
        self.logger = CustomLogger("Game Class", logging_level)

        from typing import Callable

        self.Print: Callable[
            [str, int], None] = self.logger.Print  # to override warning the Print get one argument only

        # Pygame screen adjusted
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        self.board = pygame.transform.smoothscale(b0, (BOARD_WIDTH, BOARD_HEIGHT))

        pygame.display.set_caption("Shesh‑Besh")
        self.clock = pygame.time.Clock()

        # dice & buttons
        self.dice = Dice()
        self.roll_btn = Button((BOARD_WIDTH + SIDE_PANEL_WIDTH + 20, 360, 160, 40), "Roll Dice", self.roll_dice)
        self.exit_btn = Button((BOARD_WIDTH + SIDE_PANEL_WIDTH + 20, 420, 160, 40),
                               "Exit", lambda: threading.Thread(target=self.ask_exit, daemon=True).start())

        self.function_process_by_subject = {
            "DICE_RESULT": self.process_roll,
            "GAME_STATE": self.process_game_state,
            "HIGHLIGHT": self.process_highlight,
            "CHECKER_MOVE": self.process_checker_move,
            "CHECKER_CAPTURED": self.process_checker_captured,
            "EXIT": self.process_exit
        }

        # game state
        # self.consecutive_doubles = {WHITE: 0, YELLOW: 0}
        self.just_played_double = False

        self.checkers = []
        self.bar = {WHITE: [], YELLOW: []}
        self.bear_off = {WHITE: [], YELLOW: []}
        self.turn = turn
        self.highlight = []
        self.selected = None
        self.msg = None
        self.msg_end = 0
        self.game_over = False

        self.middle_gap = 2 * BOARD_INSET
        usable_width = BOARD_WIDTH - 2 * BOARD_INSET - self.middle_gap
        self.small_gap = usable_width / 12
        Checker.R = int(self.small_gap * 0.35)
        self.stack_gap = Checker.R * 2 + 4

        # point‐to‐pixel mapping
        self.pt_xy = {}
        self.Print("Initializes board points", 10)
        self.init_points()

        # Add bear-off initialization
        self.init_bear_off_positions()

        # off‑board zones
        if not self.flipped:
            self.pt_xy[0] = (SIDE_PANEL_WIDTH + BOARD_WIDTH + PANEL_WIDTH // 2, BOARD_HEIGHT - Checker.R - BOARD_INSET)
            self.pt_xy[25] = (SIDE_PANEL_WIDTH + BOARD_WIDTH + PANEL_WIDTH // 2, Checker.R + BOARD_INSET)
        else:
            self.pt_xy[25] = (SIDE_PANEL_WIDTH + BOARD_WIDTH + PANEL_WIDTH // 2, BOARD_HEIGHT - Checker.R - BOARD_INSET)
            self.pt_xy[0] = (SIDE_PANEL_WIDTH + BOARD_WIDTH + PANEL_WIDTH // 2, Checker.R + BOARD_INSET)

        self.Print("Initializes checkers", 10)
        self.init_checkers()
        self.Print(f"Server says my color is: {player_color}", 10)
        self.Print(f"My display color is: {'WHITE' if self.player_color == WHITE else 'YELLOW'}", 10)
        self.Print(f"Flipped board: {self.flipped}", 10)

        self.running = True
        self.pressed_exit = False

    def ask_exit(self):
        if not self.game_over:
            root = tk.Tk()
            root.withdraw()
            color_will_win = "Yellow" if self.color == "White" else "White"
            result = messagebox.askokcancel("Confirm Exit", f"Exit the game? "
                                                            f"{color_will_win} will automatically win!")
            root.destroy()

            if result:
                func = Func(subject="EXIT", color=self.color)
                self.PROTO.send_one_message(("FUNCT|" + func.to_str()).encode())
        else:
            self.running = False

    def process_exit(self, func=None):
        self.Print("Received exit permission", 20)
        if func.color != self.color:
            self.game_over = True
        else:
            self.running = False

    def process_checker_captured(self, func):
        from_pt = int(func.from_pt)
        captured_color = WHITE if func.color == "White" else YELLOW

        self.Print(f"CHECKER CAPTURED:", 10)
        self.Print(f"From point: {from_pt}", 10)
        self.Print(f"Color: {func.color}", 10)

        # Find and remove the captured checker from the board
        for i, checker in enumerate(self.checkers):
            if checker.pt == from_pt and checker.color == captured_color:
                captured_checker = self.checkers.pop(i)
                self.bar[captured_color].append(captured_checker)
                self.Print(f"Moved {func.color} checker from point {from_pt} to bar", 10)
                return

        self.Print(f"Could not find {func.color} checker at point {from_pt} to capture", 40)

    def roll_dice(self):
        func = Func(subject="ROLL_DICE", color=self.color)
        self.PROTO.send_one_message(("FUNCT|" + func.to_str()).encode())

    def init_points(self):  # Ai (assisted) work at this func.
        for i in range(12):
            base = (i + 0.5) * self.small_gap

            # Calculate X positions
            x_left = SIDE_PANEL_WIDTH + BOARD_INSET + base
            x_right = SIDE_PANEL_WIDTH + BOARD_INSET + self.middle_gap + base

            global_pt_low = 12 - i  # Points 12,11,10,9,8,7 then 6,5,4,3,2,1
            global_pt_high = 13 + i  # Points 13,14,15,16,17,18 then 19,20,21,22,23,24

            # Determine X position based on global point number
            # Points 1-6 and 19-24 are on the RIGHT side
            # Points 7-12 and 13-18 are on the LEFT side
            if global_pt_low <= 6:
                x_low = x_right  # Points 1-6 on right
            else:
                x_low = x_left  # Points 7-12 on left

            if global_pt_high >= 19:
                x_high = x_right  # Points 19-24 on right
            else:
                x_high = x_left  # Points 13-18 on left

            # Y positions - THIS IS WHERE THE FLIP HAPPENS
            if not self.flipped:  # WHITE player view
                # White sees: bottom points 1-12, top points 13-24
                y_low = BOARD_HEIGHT - Checker.R - 8 - BOARD_INSET  # bottom
                y_high = Checker.R + 8 + BOARD_INSET  # top
            else:  # YELLOW player view
                # Yellow sees: top points 1-12, bottom points 13-24
                y_low = Checker.R + 8 + BOARD_INSET  # top (flipped!)
                y_high = BOARD_HEIGHT - Checker.R - 8 - BOARD_INSET  # bottom (flipped!)

            self.pt_xy[global_pt_low] = (x_low, y_low)
            self.pt_xy[global_pt_high] = (x_high, y_high)

    def init_bear_off_positions(self):  # I greatly dislike making a front-hand. Ai work at this func.
        bear_off_x = SIDE_PANEL_WIDTH + BOARD_WIDTH + PANEL_WIDTH // 2

        if not self.flipped:  # WHITE player view
            # Point 0 (White bear-off) at bottom
            self.pt_xy[0] = (bear_off_x, BOARD_HEIGHT - Checker.R - BOARD_INSET)
            # Point 25 (Yellow bear-off) at top
            self.pt_xy[25] = (bear_off_x, Checker.R + BOARD_INSET)
        else:  # YELLOW player view
            # Point 25 (Yellow bear-off) at bottom (for Yellow player)
            self.pt_xy[25] = (bear_off_x, BOARD_HEIGHT - Checker.R - BOARD_INSET)
            # Point 0 (White bear-off) at top (for Yellow player)
            self.pt_xy[0] = (bear_off_x, Checker.R + BOARD_INSET)

    def init_checkers(self):  # Ai (assisted!) work at this func.
        white_setup = {
            24: 2,
            13: 5,
            8: 3,
            6: 5
        }

        yellow_setup = {
            1: 2,
            12: 5,
            17: 3,
            19: 5
        }

        # Add white checkers
        for pt, count in white_setup.items():
            for i in range(count):
                checker = Checker(pt, WHITE)
                self.checkers.append(checker)

        # Add yellow checkers
        for pt, count in yellow_setup.items():
            for i in range(count):
                checker = Checker(pt, YELLOW)
                self.checkers.append(checker)

    def run(self):
        try:
            while self.running:
                try:
                    now = pygame.time.get_ticks()
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            if self.game_over:
                                self.running = False  # Allow close if game is over
                            else:
                                # If game is not over, treat like exit button
                                threading.Thread(target=self.ask_exit, daemon=True).start()
                        if self.exit_btn.handle(event):
                            if self.game_over:
                                pygame.quit()
                                import sys
                                sys.exit(0)
                            continue
                        if self.game_over and self.pressed_exit:
                            pygame.quit()
                            import sys
                            sys.exit(0)
                        if self.roll_btn.handle(event):
                            continue
                        if not self.running:
                            break
                        if event.type == pygame.MOUSEBUTTONDOWN:
                            self.on_click(event.pos)

                    if self.msg and not self.game_over and now > self.msg_end:
                        self.msg = None

                    self.draw()
                    pygame.display.flip() # update screen
                    self.clock.tick(FPS)

                    if not self.running:
                        break

                except Exception as e:
                    self.Print(f"Exception in Game.run(): {e}", 50)
                    import traceback
                    traceback.print_exc()
                    # Continue the loop - don't break unless it's a fatal error

        finally:
            self.Print("Shutting down pygame", 10)
            pygame.display.quit()
            pygame.quit()
            import sys
            sys.exit(0)

    def on_click(self, pos):
        pt = self.get_point_from_pos(pos[0], pos[1])
        if pt is None:
            self.Print(f"Click at {pos} -> No valid point", 30)
            return

        if pt == self.selected:
            self.Print(f"Deselecting point {pt}", 10)
            self.selected = None
            self.highlight = []
            return

        if pt in self.highlight and self.selected is not None:
            self.Print(f"Moving from {self.selected} to {pt}", 10)
            func = Func(subject="MOVE_TO", from_pt=self.selected, to_pt=pt, color=self.color)
            self.PROTO.send_one_message(("FUNCT|" + func.to_str()).encode())
            self.highlight = []
            self.selected = None
            return

        # selecting other checker
        self.Print(f"Selecting point {pt}", 10)
        func = Func(subject="SELECT_PT", pt=pt, color=self.color)
        self.PROTO.send_one_message(("FUNCT|" + func.to_str()).encode())

    def get_point_from_pos(self, x, y):  # I greatly dislike making a front-hand. Ai work at this func.
        """Get global board point number based on click position"""

        # Check if click is in the bear-off area (right panel)
        bear_off_x_start = SIDE_PANEL_WIDTH + BOARD_WIDTH
        bear_off_x_end = bear_off_x_start + PANEL_WIDTH

        if bear_off_x_start <= x <= bear_off_x_end:
            # Click is in bear-off area - determine which bear-off based on Y position
            if not self.flipped:
                # WHITE player view
                if y > BOARD_HEIGHT / 2:
                    return 0  # White bear-off (bottom for White player)
                else:
                    return 25  # Yellow bear-off (top for White player)
            else:
                # YELLOW player view (flipped)
                if y > BOARD_HEIGHT / 2:
                    return 25  # Yellow bear-off (bottom for Yellow player)
                else:
                    return 0  # White bear-off (top for Yellow player)

        adjusted_x = x - SIDE_PANEL_WIDTH - BOARD_INSET
        if adjusted_x < 0:
            return None

        # Check if click is in the middle bar area
        middle_start = 6 * self.small_gap
        middle_end = middle_start + self.middle_gap
        if middle_start <= adjusted_x < middle_end:
            if not self.flipped:
                # WHITE player view: white bar on TOP half, yellow bar on BOTTOM half
                if y < BOARD_HEIGHT / 2:
                    return 0  # White bar (point 0) - drawn above center
                else:
                    return 25  # Yellow bar (point 25) - drawn below center
            else:
                # YELLOW player view: yellow bar on TOP half, white bar on BOTTOM half
                if y < BOARD_HEIGHT / 2:
                    return 25  # Yellow bar (point 25) - drawn above center when flipped
                else:
                    return 0  # White bar (point 0) - drawn below center when flipped

        # Determine column (0-11) for regular board points
        if adjusted_x < middle_start:
            col = int(adjusted_x // self.small_gap)
        else:
            col = int((adjusted_x - self.middle_gap) // self.small_gap)

        if not 0 <= col < 12:
            return None

        # Determine if click is on top or bottom half
        click_on_bottom = y > BOARD_HEIGHT / 2

        # Calculate global point based on player perspective
        if not self.flipped:  # WHITE player
            if click_on_bottom:
                # Bottom row: points 12,11,10,9,8,7 then 6,5,4,3,2,1
                global_pt = 12 - col
            else:
                # Top row: points 13,14,15,16,17,18 then 19,20,21,22,23,24
                global_pt = 13 + col
        else:  # YELLOW player (flipped view)
            if click_on_bottom:
                # What looks like bottom for Yellow is actually top points
                # Bottom row: points 13,14,15,16,17,18 then 19,20,21,22,23,24
                global_pt = 13 + col
            else:
                # What looks like top for Yellow is actually bottom points
                # Top row: points 12,11,10,9,8,7 then 6,5,4,3,2,1
                global_pt = 12 - col

        return global_pt

    def process_game_state(self, func):
        self.turn = func.turn
        my_color_str = self.color
        is_my_turn = (self.turn == self.color)
        self.game_over = func.game_over == "True"

        self.Print(f"GAME STATE UPDATE", 10)
        self.Print(f"My color: {my_color_str}", 10)
        self.Print(f"Board turn: {func.turn}", 10)
        self.Print(f"Is my turn: {is_my_turn}", 10)

        if func.info:
            self.Print(f"Info is: {func.info}", 10)
            self.show_msg(func.info, 2000)

    def process_highlight(self, func):
        self.highlight = [(int(pt)) for pt in func.points.split(',')]
        self.selected = (int(func.pt))

    def process_checker_move(self, func):
        from_pt = int(func.from_pt)
        to_pt = int(func.to_pt)
        color = WHITE if func.color == "White" else YELLOW

        self.Print(f"CHECKER MOVE", 10)
        self.Print(f"From: {from_pt}, To: {to_pt}", 10)
        self.Print(f"Color: {func.color}", 10)

        # Handle bar to board moves
        if from_pt == 0 or from_pt == 25:
            if color in self.bar and self.bar[color]:
                checker = self.bar[color].pop()
                checker.pt = to_pt
                self.checkers.append(checker)
                self.Print(f"Moved from bar to point {to_pt}", 10)
                return

        # Handle board to bear-off moves
        if to_pt == 0 or to_pt == 25:
            for i, checker in enumerate(self.checkers):
                if checker.pt == from_pt and checker.color == color:
                    self.checkers.pop(i)
                    self.bear_off[color].append(checker)
                    self.Print(f"Bore off from point {from_pt}", 10)
                    return

        for checker in self.checkers:
            if checker.pt == from_pt and checker.color == color:
                checker.pt = to_pt
                self.Print(f"Moved on board from {from_pt} to {to_pt}", 10)
                break

    def process_error(self, func):
        self.Print(f"ERROR TYPE: {func.subject}, {func.info}", 40)
        self.show_msg(func.info, 2000)

    def show_msg(self, text, ms):
        self.msg = text
        self.msg_end = pygame.time.get_ticks() + ms

    def draw(self):  # I greatly dislike making a front-hand. Ai work at this func.
        self.font_med = pygame.font.SysFont(None, 32)
        self.font_sm = pygame.font.SysFont(None, 24)

        # Clear screen
        self.screen.fill(GRAY)

        # Draw left panel
        pygame.draw.rect(self.screen, PANEL_GREEN, (0, 0, SIDE_PANEL_WIDTH, WINDOW_HEIGHT))

        # Player info
        self.screen.blit(self.font_sm.render("Player:", True, BLACK), (20, 40))
        self.screen.blit(self.font_sm.render(self.player_username, True, BLACK), (20, 70))

        self.screen.blit(self.font_sm.render("Opponent:", True, BLACK), (20, 130))
        self.screen.blit(self.font_sm.render(self.opponent_username, True, BLACK), (20, 160))

        color_text = "White" if self.player_color == WHITE else "Yellow"
        self.screen.blit(self.font_sm.render("Color:", True, BLACK), (20, 220))
        self.screen.blit(self.font_sm.render(color_text, True, self.player_color), (20, 250))

        # Draw the board
        self.screen.blit(self.board, (SIDE_PANEL_WIDTH, 0))

        # Draw right panel
        pygame.draw.rect(self.screen, BG, (SIDE_PANEL_WIDTH + BOARD_WIDTH, 0, PANEL_WIDTH, WINDOW_HEIGHT))

        # ─── bear‑off stacks ───────────
        for i, c in enumerate(self.bear_off[WHITE]):
            x, y = self.pt_xy[0]
            c.draw(self.screen, x, y - i * self.stack_gap)
        for i, c in enumerate(self.bear_off[YELLOW]):
            x, y = self.pt_xy[25]
            c.draw(self.screen, x, y + i * self.stack_gap)

        # ─── bar ───────────────────────
        bx = SIDE_PANEL_WIDTH + BOARD_INSET + 6 * self.small_gap
        for i, c in enumerate(self.bar[WHITE]):
            y = BOARD_HEIGHT / 2 - (i + 1) * self.stack_gap
            if self.flipped:
                y = BOARD_HEIGHT / 2 + (i + 1) * self.stack_gap
            c.draw(self.screen, bx, y)

        for i, c in enumerate(self.bar[YELLOW]):
            y = BOARD_HEIGHT / 2 + (i + 1) * self.stack_gap
            if self.flipped:
                y = BOARD_HEIGHT / 2 - (i + 1) * self.stack_gap
            c.draw(self.screen, bx, y)

        # ─── highlights ─────────────────
        for pt in self.highlight:
            x, y = self.pt_xy[(pt)]
            pygame.draw.circle(self.screen, GREEN,
                               (int(x), int(y)),
                               Checker.R + HIGHLIGHT_PADDING, 4)

        # ─── on‑point checkers ──────────
        stacks = {}
        for c in self.checkers:
            if c.pt not in stacks:
                stacks[c.pt] = []
            stacks[c.pt].append(c)

        for pt, group in stacks.items():
            x, y_base = self.pt_xy[(pt)]
            up = y_base < BOARD_HEIGHT / 2
            for i, checker in enumerate(group):
                offset = i * (Checker.R * 2 + 6)
                y = y_base + offset if up else y_base - offset
                checker.draw(self.screen, x, y)

        # ─── side‑panel UI ─────────────
        turn_txt = self.font_med.render(f"Turn: {self.turn}", True, BLACK)

        self.screen.blit(turn_txt, (SIDE_PANEL_WIDTH + BOARD_WIDTH + 20, 20))
        self.dice.draw(self.screen, SIDE_PANEL_WIDTH + BOARD_WIDTH + 30, 100)
        self.roll_btn.draw(self.screen)
        self.exit_btn.draw(self.screen)

        # ─── message overlay ───────────
        if self.msg:
            overlay_msg = pygame.Surface((BOARD_WIDTH, 60), pygame.SRCALPHA)
            overlay_msg.fill(SEMI_BG)
            self.screen.blit(overlay_msg, (SIDE_PANEL_WIDTH, BOARD_HEIGHT // 2 - 30))
            txt = self.font_med.render(self.msg, True, WHITE)
            self.screen.blit(txt, txt.get_rect(
                center=(SIDE_PANEL_WIDTH + BOARD_WIDTH // 2, BOARD_HEIGHT // 2)))

        # ─── game‑over freeze overlay ───
        if self.game_over:
            # full‑screen darkener
            overlay_full = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
            overlay_full.fill(SEMI_BG)
            self.screen.blit(overlay_full, (0, 0))

            # permanent centered message
            msg_txt = self.font_med.render(self.msg, True, WHITE)
            msg_rect = msg_txt.get_rect(center=(SIDE_PANEL_WIDTH + BOARD_WIDTH // 2, BOARD_HEIGHT // 2))
            self.screen.blit(msg_txt, msg_rect)

            # draw Exit on top so it's still visible and clickable
            self.exit_btn.draw(self.screen)
        else:
            # draw Roll only if game is still going
            self.roll_btn.draw(self.screen)
            self.exit_btn.draw(self.screen)

    def process_func(self, func):
        self.Print(f"Received func. subject = {func.subject}", 10)
        if "ERR" in func.subject:
            self.process_error(func)
        else:
            self.function_process_by_subject[func.subject](func)

    def process_roll(self, func):
        self.Print(f"Dice rolled: {func.num1},{func.num2}", 20)
        num1, num2 = int(func.num1), int(func.num2)
        self.dice.values = [num1, num2]
        self.show_msg("Dice has rolled!", 3000)
