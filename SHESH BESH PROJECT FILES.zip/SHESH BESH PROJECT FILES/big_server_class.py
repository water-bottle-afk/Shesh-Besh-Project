__author__ = "Nadav"

"""
The "big server class" uses the server class, to match between client to a mini-srv for himself.
"""

import socket
import threading
from server_class import Server
from classes import CustomLogger


class Big_Server:
    def __init__(self, ip, port, logging_level):
        self.srv_socket = socket.socket()
        self.ip = ip
        self.port = port
        self.to_continue = True
        self.show_db = True
        self.logger = CustomLogger("Big Server Class", logging_level)
        self.Print = self.logger.Print
        self.logging_level = logging_level

        self.tid = 0

    def run(self, lst_of_mini_servers):
        try:
            self.lst = lst_of_mini_servers
            self.srv_socket.bind((self.ip, self.port))
            self.srv_socket.listen(5)
            self.Print("Big server is running..", 10)
            while self.to_continue:
                self.tid += 1
                cln_sock, addr = self.srv_socket.accept()
                t = threading.Thread(target=self.handle_client, args=(cln_sock, addr, self.tid))
                t.start()
        except OSError as e:
            self.Print(f"CONNECTION ERROR! {e}", 50)
        except Exception as e:
            self.Print(f"ERROR! {e}", 50)

    def handle_client(self, cln_sock, addr, tid):
        mini_srv = Server(cln_sock, addr, self.logging_level, tid)
        self.lst.append(mini_srv)
        if self.show_db:
            self.Print(mini_srv.get_users(), 10)
            self.show_db = False
        mini_srv.run()
