__author__ = "Nadav"

from big_server_class import Big_Server
from classes import UDPServer
from big_game_server_class import big_game_srv
import threading

TCP_IP = "10.100.102.58"
TCP_PORT = 55655
UDP_IP = "10.100.102.58"
UDP_PORT = 57071
LOGGING_LEVEL = 10
lst_of_mini_servers = []
RUN_UDP_SRV = True


# Server setup
def run_tcp_server():
    srv = Big_Server(TCP_IP, TCP_PORT, LOGGING_LEVEL)
    srv.run(lst_of_mini_servers)


def run_udp_server():
    udp_srv = UDPServer(UDP_IP, UDP_PORT, TCP_IP, TCP_PORT, LOGGING_LEVEL)
    udp_srv.run()


def run_game_thread():
    game_srv = big_game_srv(LOGGING_LEVEL)
    game_srv.run(lst_of_mini_servers)


if __name__ == "__main__":
    ans = input("Activate UDP server? Y / N --->")
    if ans != 'Y':
        RUN_UDP_SRV = False

    tcp_thread = threading.Thread(target=run_tcp_server)
    game_srv_thread = threading.Thread(target=run_game_thread)

    tcp_thread.start()
    game_srv_thread.start()

    if RUN_UDP_SRV:
        udp_thread = threading.Thread(target=run_udp_server)
        udp_thread.start()

    tcp_thread.join()
    game_srv_thread.join()

    if RUN_UDP_SRV:
        udp_thread.join()
