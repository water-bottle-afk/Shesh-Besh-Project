__author__ = "Nadav"

from classes import UDPServer

SELF_IP = "10.100.102.58"
SELF_PORT = 57071
TCP_IP = "10.100.102.58"
TCP_PORT = 55653
LOGGING_LEVEL = 10
udp_srv = UDPServer(SELF_IP,SELF_PORT,TCP_IP,TCP_PORT,LOGGING_LEVEL)
udp_srv.run()
