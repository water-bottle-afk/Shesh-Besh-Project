__author__ = "Nadav"

"""
The "big game server class" uses the game server class, to match between clients to game.
"""

import threading
import time

from game_server_class import game_srv
from classes import CustomLogger


class big_game_srv():
    def __init__(self, logging_level):
        self.count_games = 1
        self.to_continue = True
        self.in_game_srvs = []
        self.logger = CustomLogger("Big Game Server Class", logging_level)
        self.Print = self.logger.Print
        self.logging_level = logging_level

    def return_two_srvs_available(self, lst):
        srv1 = None
        srv2 = None
        for item in lst:
            if item.is_ready_for_game and item not in self.in_game_srvs:
                if srv1 is None:
                    srv1 = item
                else:
                    srv2 = item
                    break
        if srv1 and srv2:
            self.in_game_srvs.append(srv1)
            self.in_game_srvs.append(srv2)
            return srv1, srv2
        return None, None

    def handle_game(self, srv1, srv2, idx):
        game_server = game_srv(srv1, srv2, self.logging_level, self.in_game_srvs, idx)
        game_server.run()

    def run(self, lst_of_mini_servers):
        idx = 1
        while self.to_continue:
            srv1, srv2 = self.return_two_srvs_available(lst_of_mini_servers)
            if srv1 is None and srv2 is None:
                time.sleep(5)
                self.Print("servers in game:", 10)
                self.Print(self.in_game_srvs, 10)

            else:
                t = threading.Thread(target=self.handle_game, args=(srv1, srv2, idx)).start()
                self.Print("servers in game:", 10)
                self.Print(self.in_game_srvs, 10)
