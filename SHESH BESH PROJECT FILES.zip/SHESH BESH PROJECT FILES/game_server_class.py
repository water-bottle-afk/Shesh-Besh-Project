__author__ = "Nadav"  # with teamwork of AI.

import time
import threading
import random
from classes import Func, CustomLogger

WHITE = "White"
YELLOW = "Yellow"
dict_of_colors = {1: "White", 2: "Yellow"}


class game_srv:
    def __init__(self, srv1, srv2, logging_level, in_game_servers, idx):
        self.process_by_subject_names = {
            "ROLL_DICE": self.process_roll_dice,
            "SELECT_PT": self.process_select_pt,
            "MOVE_TO": self.process_move_to,
            "EXIT": self.manage_exit
        }
        self.srv1 = srv1
        self.srv2 = srv2
        self.logger = CustomLogger(f"Game Server Class no.{idx}", logging_level)
        self.Print = self.logger.Print
        self.logging_level = logging_level
        self.board = Board(self.logging_level)
        self.in_game_servers = in_game_servers
        self.white, self.yellow = None, None

        self.player_exit_status = {self.srv1: False, self.srv2: False}

    def start_match(self):
        num = random.randint(1, 2)
        if num == 1:
            self.white = self.srv1
            self.yellow = self.srv2
            starting_player = self.srv1
            self.Print(f"srv1 ({self.srv1.username}) = WHITE, srv2 ({self.srv2.username}) = YELLOW", 10)
        else:
            self.white = self.srv2
            self.yellow = self.srv1
            starting_player = self.srv2
            self.Print(f"srv2 ({self.srv2.username}) = WHITE, srv1 ({self.srv1.username}) = YELLOW", 10)

        self.board.turn = "White" if self.white == self.srv1 else "Yellow"

        self.Print(f"Game starts with WHITE turn ({starting_player.username})", 10)
        self.Print(f"Assigning colors: WHITE = {self.white.username}, YELLOW = {self.yellow.username}", 10)

        func_for_s1 = Func(subject="MATCH", color=dict_of_colors[num], opponent=self.srv2.username,
                           turn=self.board.turn)
        func_for_s2 = Func(subject="MATCH", color=dict_of_colors[3 - num], opponent=self.srv1.username,
                           turn=self.board.turn)

        self.srv1.moves_to_perform.put("FUNCT|" + func_for_s1.to_str())
        self.srv2.moves_to_perform.put("FUNCT|" + func_for_s2.to_str())

        time.sleep(0.5)
        initial_turn = self.board.turn
        initial_state = Func(subject="GAME_STATE", turn=initial_turn)
        self.srv1.moves_to_perform.put("FUNCT|" + initial_state.to_str())
        self.srv2.moves_to_perform.put("FUNCT|" + initial_state.to_str())

    def next_turn_color(self):
        return "White" if self.board.turn == WHITE else "Yellow"

    def process_clients_moves(self):
        while self.srv1 in self.in_game_servers or self.srv2 in self.in_game_servers:
            if self.srv1 in self.in_game_servers and self.srv1.moves_to_check_by_game_server:
                self.process_move(self.srv1, self.srv1.moves_to_check_by_game_server.pop(0))
            if self.srv2 in self.in_game_servers and self.srv2.moves_to_check_by_game_server:
                self.process_move(self.srv2, self.srv2.moves_to_check_by_game_server.pop(0))
        self.Print("Game server finished.", 10)

    def process_move(self, srv, func):
        if func.subject == "EXIT":
            self.Print(f"DEBUG: EXIT request from {srv.username}", 10)
            self.manage_exit(srv, func)
            return
        self.process_by_subject_names[func.subject](srv, func)

    def process_roll_dice(self, srv, func):
        player_color = "White" if srv == self.white else "Yellow"
        self.Print(f"Roll attempt - Player: {srv.username}, Color: {player_color}", 10)
        self.Print(f" Board turn: {self.board.turn}", 10)

        if self.board.turn != player_color:
            self.Print(f"Not your turn! Board turn: {self.board.turn}, player: {player_color}", 40)
            srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR50', info='Not your turn').to_str()}")
            return

        success, dice, winning_msg = self.board.roll_dice()
        if not success:
            if winning_msg is not None:
                dice_msg = Func(subject="DICE_RESULT", num1=dice[0], num2=dice[1])
                self.srv1.moves_to_perform.put("FUNCT|" + dice_msg.to_str())
                self.srv2.moves_to_perform.put("FUNCT|" + dice_msg.to_str())

                winner_msg = Func(subject="GAME_STATE", info=winning_msg, game_over="True", turn=player_color)
                for s in (self.srv1, self.srv2):
                    s.moves_to_perform.put(f"FUNCT|{winner_msg.to_str()}")
                    s.is_ready_for_game = False  # Prevent automatic return to game list
                    self.in_game_servers.remove(s)
                    self.Print(f"Removed {s.username} from in_game_servers", 10)
                return

            self.Print(f"ERROR in rolling dice from {srv.username}", 40)
            srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR51', info=dice).to_str()}")
            return

        dice_msg = Func(subject="DICE_RESULT", num1=dice[0], num2=dice[1])
        self.srv1.moves_to_perform.put("FUNCT|" + dice_msg.to_str())
        self.srv2.moves_to_perform.put("FUNCT|" + dice_msg.to_str())

        if not self.board.moves_left:
            self.board.end_turn()
            new_turn = self.next_turn_color()
            self.Print(f"No legal moves available, ending turn for {srv.username}", 30)
            msg = Func(subject="GAME_STATE", info="No legal moves", turn=new_turn)
            for s in [self.srv1, self.srv2]:
                s.moves_to_perform.put(f"FUNCT|{msg.to_str()}")

        elif self.board.bar[player_color] and not self.board.has_moves():
            self.board.end_turn()
            new_turn = self.next_turn_color()
            self.Print(f"Player {srv.username} has checkers on bar but no valid entry moves, ending turn", 40)
            msg = Func(subject="GAME_STATE", info="No valid moves from bar - all entry points blocked",
                       turn=new_turn)
            for s in [self.srv1, self.srv2]:
                s.moves_to_perform.put(f"FUNCT|{msg.to_str()}")
        else:
            current_turn = self.next_turn_color()
            if self.board.has_rolled:
                current_turn = "White" if self.board.turn == WHITE else "Yellow"
            state = Func(subject="GAME_STATE", turn=current_turn)
            for s in [self.srv1, self.srv2]:
                s.moves_to_perform.put("FUNCT|" + state.to_str())

    def process_select_pt(self, srv, func):
        pt = int(func.pt)
        player_color = WHITE if srv == self.white else YELLOW
        self.Print(f"Select attempt - Player: {srv.username}, Color: {player_color}, Point: {pt}", 10)

        if self.board.turn != player_color:
            self.Print(f"Not your turn! Board turn: {self.board.turn}, player: {player_color}", 40)
            srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR50', info='Not your turn').to_str()}")
            return

        if self.board.bar[player_color] and (pt != 0 and pt != 25):
            srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR52', info='Must move checker from bar first').to_str()}")
            return

        if pt == 0 or pt == 25:  # handling bars
            expected_bar_pt = 0 if player_color == WHITE else 25
            if pt != expected_bar_pt:
                srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR53', info='Wrong bar position').to_str()}")
                return

            if not self.board.bar[player_color]:
                srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR54', info='No checker on bar').to_str()}")
                return

            # where checker can enter from bar:
            valid_moves = []
            enemy = YELLOW if player_color == WHITE else WHITE

            for d in set(self.board.moves_left):
                if player_color == WHITE:
                    entry_pt = 24 - d + 1  # Dice 1->24, 2->23, 3->22, 4->21, 5->20, 6->19
                    if 19 <= entry_pt <= 24:
                        enemy_count = sum(1 for c in self.board.checkers if c.pt == entry_pt and c.color == enemy)
                        if enemy_count < 2:
                            valid_moves.append(entry_pt)
                else:
                    entry_pt = d  # Dice 1->1, 2->2, 3->3, 4->4, 5->5, 6->6
                    if 1 <= entry_pt <= 6:
                        enemy_count = sum(1 for c in self.board.checkers if c.pt == entry_pt and c.color == enemy)
                        if enemy_count < 2:
                            valid_moves.append(entry_pt)
        else:
            # not at bars
            stack = [c for c in self.board.checkers if c.pt == pt and c.color == player_color]
            if not stack:
                self.Print(f"ERROR No checker at this point! from {srv.username}", 40)
                srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR54', info='No checker at this point').to_str()}")
                return

            checker = stack[-1]
            valid_moves = self.board.valid_moves(checker)

        if not valid_moves:
            self.Print(f"No Valid moves for the checker!", 40)
            srv.moves_to_perform.put(
                f"FUNCT|{Func(subject='ERR55', info='No valid moves for this checker').to_str()}")
            return

        str_valid_moves = [str(item) for item in valid_moves]
        points_str = ','.join(str_valid_moves)
        highlight_msg = Func(subject="HIGHLIGHT", points=points_str, pt=pt)
        srv.moves_to_perform.put("FUNCT|" + highlight_msg.to_str())

    def process_move_to(self, srv, func):
        from_pt = int(func.from_pt)
        to_pt = int(func.to_pt)
        player_color = WHITE if srv == self.white else YELLOW
        self.Print(f"Move attempt - Player: {srv.username}, Color: {player_color}, From: {from_pt}, To: {to_pt}", 10)

        if self.board.turn != player_color:
            self.Print(f"Not your turn! Board turn: {self.board.turn}, player: {player_color}", 40)
            srv.moves_to_perform.put(f"FUNCT|{Func(subject='ERR50', info='Not your turn').to_str()}")
            return

        success, msg, captures, err_subject = self.board.apply_move(from_pt, to_pt)
        if success:
            self.send_move_messages(from_pt, to_pt, player_color, captures)
            self.handle_turn_end()
        else:
            self.Print(f"ERROR! {msg}", 40)
            srv.moves_to_perform.put(f"FUNCT|{Func(subject=err_subject, info=msg).to_str()}")

        self.check_and_send_winner()

    def send_move_messages(self, from_pt, to_pt, player_color, captures):
        move_msg = Func(subject="CHECKER_MOVE", from_pt=from_pt, to_pt=to_pt,
                        color="White" if player_color == WHITE else "Yellow")
        self.Print(f"Checker move, from {from_pt} to {to_pt}", 10)

        for s in [self.srv1, self.srv2]:
            s.moves_to_perform.put("FUNCT|" + move_msg.to_str())

        for capture in captures:
            capture_msg = Func(subject="CHECKER_CAPTURED",
                               from_pt=capture['from_pt'],
                               color=capture['color'])
            self.Print(f"Checker captured, from {capture['from_pt']}", 10)
            for s in [self.srv1, self.srv2]:
                s.moves_to_perform.put("FUNCT|" + capture_msg.to_str())

    def handle_turn_end(self):
        if not self.board.moves_left:
            self.board.end_turn()
            turn_msg = Func(subject="GAME_STATE", turn=self.board.turn)
            self.Print(f"Turn is: {self.board.turn}", 10)
            for s in [self.srv1, self.srv2]:
                s.moves_to_perform.put("FUNCT|" + turn_msg.to_str())
        else:
            # if player has checkers on bar and no valid moves remaining-> end turn
            if self.board.bar[self.board.turn] and not self.board.has_moves():
                self.board.end_turn()
                turn_msg = Func(subject="GAME_STATE",
                                info="No more valid moves from bar - turn ended",
                                turn=self.board.turn)
                self.Print(f"Player has checkers on bar but no more valid moves - ending turn", 10)
                for s in [self.srv1, self.srv2]:
                    s.moves_to_perform.put("FUNCT|" + turn_msg.to_str())

    def manage_exit(self, srv, func):
        self.Print(f"DEBUG: ENTER manage_exit for {srv.username}", 10)

        self.player_exit_status[srv] = True

        allow_exit = Func(subject="EXIT", info="Allowed to exit")
        srv.moves_to_perform.put("FUNCT|" + allow_exit.to_str())

        if srv in self.in_game_servers:
            srv.is_ready_for_game = False  # Prevent automatic return to game list
            self.in_game_servers.remove(srv)
            self.Print(f"Removed {srv.username} from in_game_servers", 10)

        other_srv = self.srv2 if srv == self.srv1 else self.srv1

        if not self.player_exit_status[other_srv]:
            winning_msg = Func(subject="GAME_STATE", info="You Won! (by opponent's abandonment)", game_over="True")
            other_srv.moves_to_perform.put("FUNCT|" + winning_msg.to_str())
            self.Print(f"WIN of {other_srv.username}! (opponent left)", 20)

            if other_srv in self.in_game_servers:
                other_srv.is_ready_for_game = False
                self.in_game_servers.remove(other_srv)
                self.Print(f"Also removed {other_srv.username} from in_game_servers (opponent abandoned)", 10)
        else:
            self.Print("Both players exited", 10)

    def check_and_send_winner(self):
        winner = self.board.check_win()
        if winner:
            dict_of_winning_msgs = {
                "White": "White wins!",
                "White_Mars": "White wins with Mars!",
                "White_Turkish_Mars": "White wins with Turkish Mars!",
                "Yellow": "Yellow wins!",
                "Yellow_Mars": "Yellow wins with Mars!",
                "Yellow_Turkish_Mars": "Yellow wins with Turkish Mars!",
            }
            win_msg = Func(subject="GAME_STATE", info=f"{dict_of_winning_msgs[winner]}", game_over="True")
            self.Print(f"WINNER: {dict_of_winning_msgs[winner]}", 20)

            for srv in (self.srv1, self.srv2):
                srv.moves_to_perform.put("FUNCT|" + win_msg.to_str())
                srv.is_ready_for_game = False  # Prevent automatic return to game list
                self.in_game_servers.remove(srv)
                self.Print(f"Removed {srv.username} from in_game_servers", 10)

    def run(self):
        self.Print("Game is running", 10)
        threading.Thread(target=self.srv1.perform_moves).start()
        threading.Thread(target=self.srv2.perform_moves).start()
        self.start_match()
        self.process_clients_moves()


class Board:
    def __init__(self, logging_level):
        self.checkers = []
        self.bar = {WHITE: [], YELLOW: []}
        self.bear_off = {WHITE: [], YELLOW: []}
        self.turn = WHITE
        self.moves_left = []
        self.dice = [0, 0]
        self.has_rolled = False
        self.is_double = False
        self.just_played_double = False
        self.game_over = False
        self.consecutive_doubles = {WHITE: 0, YELLOW: 0}
        self.init_checkers()
        self.logger = CustomLogger("Board Class", logging_level)
        self.Print = self.logger.Print
        self.logging_level = logging_level

    def init_checkers(self):
        layout = {
            24: (2, WHITE),  # 2 white checkers at point 24
            6: (5, WHITE),
            8: (3, WHITE),
            13: (5, WHITE),
            1: (2, YELLOW),  #1: 2 yellow checkers
            19: (5, YELLOW),
            17: (3, YELLOW),
            12: (5, YELLOW)
        }
        for pt, (count, col) in layout.items():
            for i in range(count):
                self.checkers.append(Checker(pt, col))

    def roll_dice(self):
        if self.has_rolled:
            return False, "Already rolled", None

        self.dice = [random.randint(1, 6), random.randint(1, 6)]
        self.is_double = self.dice[0] == self.dice[1]

        if self.is_double:
            self.moves_left = [self.dice[0]] * 4
            self.consecutive_doubles[self.turn] += 1

            if self.consecutive_doubles[self.turn] >= 3:
                winner = "Yellow" if self.turn == "White" else "White"
                self.game_over = True
                return False, self.dice, f"Three consecutive doubles - {winner} wins!"

            self.Print(f"Doubles rolled: {self.dice[0]},{self.dice[1]} - 4 moves available", 20)
        else:
            self.moves_left = self.dice[::]  # dont want copy the points
            self.consecutive_doubles[self.turn] = 0
            self.Print(f"Normal roll: {self.dice[0]},{self.dice[1]} - 2 moves available", 20)

        self.has_rolled = True

        if not self.has_moves():
            self.Print(f"No legal moves available after rolling {self.dice}", 30)
            return True, self.dice, None  # Return success but no moves available

        return True, self.dice, None

    def apply_move(self, from_pt, to_pt):
        if from_pt == 0 or from_pt == 25:
            return self.handle_bar_move(from_pt, to_pt)

        if to_pt == 0 or to_pt == 25:
            return self.handle_bear_off_move(from_pt, to_pt)

        return self.handle_regular_move(from_pt, to_pt)

    def handle_bar_move(self, from_pt, to_pt):
        captures = []

        if not self.bar[self.turn]:
            return False, "No checker on bar", [], "ERR54"

        expected_bar_pt = 0 if self.turn == WHITE else 25
        if from_pt != expected_bar_pt:
            return False, f"Wrong bar position. Expected {expected_bar_pt}", [], "ERR53"

        if self.turn == WHITE:
            if not (19 <= to_pt <= 24):
                return False, "White must enter in opponent's home (19-24)", [], "ERR56"
            dist = 24 - to_pt + 1  # Points 24,23,22,21,20,19 need dice 1,2,3,4,5,6
        else:
            if not (1 <= to_pt <= 6):
                return False, "Yellow must enter in opponent's home (1-6)", [], "ERR56"
            dist = to_pt

        if dist not in self.moves_left:
            return False, f"Invalid entry distance: {dist}. Available: {self.moves_left}", [], "ERR57"

        # Check if entry point is blocked and handle capture
        capture_result, capture_info = self.check_and_capture(to_pt)
        if capture_result == "blocked":
            return False, "Entry point blocked by opponent", [], "ERR58"
        elif capture_result == "captured":
            captures.append(capture_info)

        # Move to board
        checker = self.bar[self.turn].pop()
        checker.pt = to_pt
        self.checkers.append(checker)
        self.moves_left.remove(dist)

        self.Print(f"Entered from bar to point {to_pt} with distance {dist}", 20)
        return True, "OK", captures, None

    def handle_regular_move(self, from_pt, to_pt):
        captures = []

        stack = [c for c in self.checkers if c.pt == from_pt and c.color == self.turn]
        if not stack:
            self.Print("No checker at this point", 40)
            return False, "No checker at this point", [], "ERR54"

        checker = stack[-1]
        dist = abs(to_pt - from_pt)

        if dist not in self.moves_left:
            self.Print(f"Invalid move. distance {dist}, available moves {self.moves_left}", 40)
            return False, f"Invalid move distance: {dist}", [], "ERR57"

        capture_result, capture_info = self.check_and_capture(to_pt)
        if capture_result == "blocked":
            return False, "Destination blocked by opponent", [], "ERR58"
        elif capture_result == "captured":
            captures.append(capture_info)  # Use the returned capture info

        # Move the checker
        checker.pt = to_pt
        self.moves_left.remove(dist)

        self.Print(f"Moved from {from_pt} to {to_pt}", 20)
        return True, "OK", captures, None

    def check_and_capture(self, target_pt):
        enemy = YELLOW if self.turn == WHITE else WHITE
        target_stack = [c for c in self.checkers if c.pt == target_pt]
        enemy_count = sum(1 for c in target_stack if c.color == enemy)

        if enemy_count >= 2:
            return "blocked", None
        elif enemy_count == 1:
            captured = next(c for c in target_stack if c.color == enemy)
            capture_info = {
                'from_pt': target_pt,
                'color': "White" if enemy == WHITE else "Yellow"
            }

            # Now move the piece to bar
            self.checkers.remove(captured)
            self.bar[enemy].append(captured)
            self.Print(f"Captured {enemy} checker from point {target_pt}", 20)
            return "captured", capture_info
        else:
            return "clear", None

    def can_bear_off(self):
        if self.turn == WHITE:
            home_range = range(1, 7)
            white_checkers = []
            for ck in self.checkers:
                if ck.color == "White":
                    white_checkers.append(ck)

            for chk in white_checkers:
                checker_in_home = chk.pt in home_range
                checker_bear_off = chk in self.bear_off["White"]

                if not (checker_in_home or checker_bear_off):
                    return False

            return True
        else:
            home_range = range(19, 25)
            yellow_checkers = []
            for ck in self.checkers:
                if ck.color == "Yellow":
                    yellow_checkers.append(ck)

            for chk in yellow_checkers:
                checker_in_home = chk.pt in home_range
                checker_bear_off = chk in self.bear_off["Yellow"]

                if not (checker_in_home or checker_bear_off):
                    return False

            return True

    def is_valid_bear_off_distance(self, from_pt, dist):
        if dist in self.moves_left:
            return True

        # Find the furthest checker's distance from bear-off
        same_color_checkers = [c for c in self.checkers if c.color == self.turn]
        if self.turn == WHITE:
            pt_values = [c.pt for c in same_color_checkers]
            furthest_distance = max(pt_values) if pt_values else 0
        else:
            pt_values = [25 - c.pt for c in same_color_checkers]
            furthest_distance = max(pt_values) if pt_values else 0

        if dist < furthest_distance:
            return False

        # Check if have higher dice available
        higher_moves = [m for m in self.moves_left if m > dist]
        return len(higher_moves) > 0

    def handle_bear_off_move(self, from_pt, to_pt):
        captures = []

        # Check if all checkers are in home
        if not self.can_bear_off():
            self.Print("Cannot bear off until all checkers are in home", 40)
            return False, "Cannot bear off until all checkers are in home", [], "ERR59"

        # Calculate distance from bear-off point
        if self.turn == WHITE:
            dist = from_pt
        else:
            dist = 25 - from_pt

        # Find the checker to bear off
        stack = [c for c in self.checkers if c.pt == from_pt and c.color == self.turn]
        if not stack:
            self.Print("No checker at this point", 40)
            return False, "No checker at this point", [], "ERR54"

        checker = stack[-1]

        same_color_checkers = [c for c in self.checkers if c.color == self.turn]
        if self.turn == WHITE:
            pt_values = [c.pt for c in same_color_checkers]
            furthest_distance = max(pt_values) if pt_values else 0
        else:
            pt_values = [25 - c.pt for c in same_color_checkers]
            furthest_distance = max(pt_values) if pt_values else 0

        if dist in self.moves_left:
            dice_to_use = dist
            self.Print(f"Using exact dice {dice_to_use} to bear off from point {from_pt}", 10)
        else:
            if dist < furthest_distance:
                self.Print(
                    f"Cannot bear off from point {from_pt}"
                    f" (distance {dist}): furthest checker distance is {furthest_distance}",
                    40)
                return (False,
                        f"Cannot bear off: not the furthest checker (distance {dist}, furthest is {furthest_distance})",
                        [], "ERR60")

            # checker is at the furthest distance, can use higher dice
            higher_dice = [m for m in self.moves_left if m > dist]
            if not higher_dice:
                self.Print(f"Cannot bear off: need {dist} or higher, available moves {self.moves_left}", 40)
                return False, f"Cannot bear off: need {dist} or higher, available moves {self.moves_left}", [], "ERR60"

            dice_to_use = higher_dice[0]
            self.Print(
                f"Using higher dice {dice_to_use} "
                f"(needed {dist}) to bear off furthest checker from point {from_pt}", 10)

        # Move checker to bear-off
        self.checkers.remove(checker)
        self.bear_off[self.turn].append(checker)
        self.moves_left.remove(dice_to_use)

        self.Print(f"Bore off checker from point {from_pt} using dice {dice_to_use}", 10)
        return True, "OK", captures, None

    def end_turn(self):
        """Called when there are no moves left"""
        # For doubles, player gets to roll again (but doesn't change turn)
        if self.is_double:
            self.Print("Double completed - same player rolls again!", 10)
            self.has_rolled = False
            self.is_double = False
            self.moves_left = []
            # Turn stays the same - don't change self.turn
            return

        # Normal turn end - switch players
        self.turn = "Yellow" if self.turn == "White" else "White"
        self.has_rolled = False
        self.is_double = False
        self.moves_left = []
        self.Print(f"Turn switched to: {self.turn}", 20)

    def move_dir(self, color):
        return -1 if color == WHITE else 1  # WHITE moves 24→1, YELLOW moves 1→24

    def check_win(self):
        white_done = len(self.bear_off["White"]) == 15
        yellow_done = len(self.bear_off["Yellow"]) == 15

        if white_done:
            yellow_in_white_home = False
            for checker in self.checkers:
                if checker.color == "Yellow" and checker.pt in range(1, 7):
                    yellow_in_white_home = True
                    break

            if yellow_in_white_home:
                return "White_Turkish_Mars"

            yellow_bore_off_count = len(self.bear_off["Yellow"])
            if yellow_bore_off_count == 0:
                return "White_Mars"

            return "White"

        if yellow_done:
            white_in_yellow_home = False
            for checker in self.checkers:
                if checker.color == "White" and checker.pt in range(19, 25):
                    white_in_yellow_home = True
                    break

            if white_in_yellow_home:
                return "Yellow_Turkish_Mars"

            white_bore_off_count = len(self.bear_off["White"])
            if white_bore_off_count == 0:
                return "Yellow_Mars"

            return "Yellow"
        return None

    def valid_moves(self, checker):
        # If player has checkers on bar, only bar checkers can move
        if self.bar[checker.color] and checker not in self.bar[checker.color]:
            return []

        # Handle bar moves
        if checker in self.bar[checker.color]:
            res = []
            enemy = YELLOW if checker.color == WHITE else WHITE

            for d in set(self.moves_left):
                if checker.color == WHITE:
                    entry_pt = 24 - d + 1
                    if 19 <= entry_pt <= 24:
                        enemy_count = sum(1 for c in self.checkers if c.pt == entry_pt and c.color == enemy)
                        if enemy_count < 2:
                            res.append(entry_pt)
                else:
                    entry_pt = d
                    if 1 <= entry_pt <= 6:
                        enemy_count = sum(1 for c in self.checkers if c.pt == entry_pt and c.color == enemy)
                        if enemy_count < 2:
                            res.append(entry_pt)
            return res

        # Regular board moves
        res = []
        dir = self.move_dir(checker.color)
        enemy = YELLOW if checker.color == WHITE else WHITE

        # Check regular moves on the board
        for dice in set(self.moves_left):
            target_point = checker.pt + dir * dice
            if 1 <= target_point <= 24:
                enemy_count = sum(1 for c in self.checkers if c.pt == target_point and c.color == enemy)
                if enemy_count < 2:
                    res.append(target_point)

        if self.can_bear_off():
            if checker.color == WHITE:
                bear_off_distance = checker.pt
                bear_off_point = 0
            else:
                bear_off_distance = 25 - checker.pt
                bear_off_point = 25

            # Find furthest checker's distance
            same_color_checkers = [c for c in self.checkers if c.color == checker.color]
            if checker.color == WHITE:
                furthest_distance = max([c.pt for c in same_color_checkers], default=0)
            else:
                furthest_distances = [25 - c.pt for c in same_color_checkers]
                furthest_distance = max(furthest_distances, default=0)

            # Check bear-off possibilities
            for dice in set(self.moves_left):
                if bear_off_distance == dice:
                    res.append(bear_off_point)
                elif bear_off_distance == furthest_distance and dice > bear_off_distance:
                    res.append(bear_off_point)

        return res

    def has_moves(self):
        # If player has checkers on bar, only check bar moves
        if self.bar[self.turn]:
            enemy = YELLOW if self.turn == WHITE else WHITE
            for dice in set(self.moves_left):
                if self.turn == WHITE:
                    entry_pt = 24 - dice + 1
                    if 19 <= entry_pt <= 24:
                        # the sum works cuz True is 1
                        enemy_checkers_at_pt = sum(c.pt == entry_pt and c.color == enemy for c in self.checkers)
                        if enemy_checkers_at_pt < 2:
                            return True
                else:  # YELLOW
                    entry_pt = dice
                    if 1 <= entry_pt <= 6:
                        enemy_checkers_at_pt = sum(c.pt == entry_pt and c.color == enemy for c in self.checkers)
                        if enemy_checkers_at_pt < 2:
                            return True
            return False

        # If no checkers on bar, check regular moves
        for c in [c for c in self.checkers if c.color == self.turn]:
            if self.valid_moves(c):
                return True
        return False


class Checker:
    def __init__(self, pt, color):
        self.pt = pt
        self.color = color
