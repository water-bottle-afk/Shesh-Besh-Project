__author__ = "Nadav"  # with teamwork of AI.

import customtkinter as ctk
from customtkinter import CTkImage
import threading
from tkinter.messagebox import showinfo
from classes import PROTO, Func, CustomLogger
from PIL import Image
import game_class
import tkinter as tk
import time

# Save the original method
original_canvas_delete = tk.Canvas.delete


def safe_canvas_delete(self, *args):
    try:
        # Check if the canvas widget still exists
        self.winfo_exists()  # This will raise TclError if destroyed
        return original_canvas_delete(self, *args)
    except tk.TclError:
        # Canvas is destroyed, silently ignore
        pass


# Replace the method globally
tk.Canvas.delete = safe_canvas_delete


class Client():
    tk.Canvas.delete = safe_canvas_delete

    def __init__(self, ip, port, logging_level):

        self.game = None
        self.logger = CustomLogger("Client", logging_level)
        self.Print = self.logger.Print
        self.logging_level = logging_level
        self.PROTO = PROTO("Client", logging_level=logging_level)
        self.PROTO.connect(ip, port)

        # Functions dictionary
        self.function_dict = {
            "Login": self.login_clicked,
            "Sign up": self.signup_clicked,
            "Get verification code": self.get_verification_code,
            "Verify code": self.verify_code,
            "Update password": self.update_user_password
        }

        self.dict_of_operations = {"LOGED": self.process_login, "SIGND": self.proccess_signup,
                                   "SENTM": self.process_get_verification_code, 'VRFYD': self.process_verify_code,
                                   'UPDTD': self.process_update_user_password, 'ANSPB': self.show_problem_info,
                                   "FUNCT": self.process_func, "LISTD": self.process_start_lobby,
                                   "CACLD": self.process_cancel,
                                   'EXTLG': self.process_logout}

        # Add these new instance variables for GIF animation control
        self.animating = False
        self.gif_frames = []
        self.gif_frame_index = 0
        self.animation_job = None  # Store the after() job ID

        self.is_encrypted = False

        self.set_window()
        self.window.mainloop()
        self.ready_for_game = False

        self.username_for_game = ""

    def recv_loop(self):
        """
        starting only after the encryption phase
        """
        while True:
            try:
                bin_content = self.PROTO.recv_one_message()
                query, data = bin_content.decode().split('|', maxsplit=1)
                if "ERR" in query:
                    threading.Thread(
                        target=self.show_problem_info, args=(query, data), daemon=True).start()  # close after ending
                elif query in self.dict_of_operations:
                    threading.Thread(target=self.dict_of_operations[query], args=(data,), daemon=True).start()
                else:
                    self.Print(f"Unrecognized query: {query}", 40)
            except Exception as e:
                self.Print(f"Error in recv_loop: {e}", 50)

    def show_problem_info(self, query, data):
        self.Print(f"ERROR TYPE: {query}, {data}", 40)
        showinfo(title="Information", message=data)

    def login_clicked(self, val_after1=None):
        """ login process """
        msg = f"CONCT|{self.username.get()}|{self.password.get()}"
        if len(msg) <= 60000:  # the size field is two bytes
            self.PROTO.send_one_message(msg.encode())
        else:
            showinfo(title="Information", message="At least ONE fields is too long!!")

    def process_login(self, data):
        showinfo(title="Information", message=data)
        self.username_for_game = self.username.get()
        self.clear()
        self.window.after(0, self.until_game_tab)

    def signup_clicked(self):
        msg = f"SGNUP|{self.username.get()}|{self.password.get()}|{self.validate_password.get()}|{self.email.get()}"
        if len(msg) <= 60000:  # the size field is two bytes
            self.PROTO.send_one_message(msg.encode())
        else:
            showinfo(title="Information", message="At least ONE field is too long!!")

    def proccess_signup(self, data):
        showinfo(title="Information", message=data)
        self.clear()

    def get_verification_code(self):
        """ email vericifcation code process"""
        email_receiver = self.email.get()
        msg = f"SCODE|{email_receiver}"
        if len(msg) <= 60000:  # the size field is two bytes
            self.PROTO.send_one_message(msg.encode())
        else:
            showinfo(title="Information", message="At least ONE fields is too long!!")

    def process_get_verification_code(self, data):
        showinfo(title="Information", message=data)
        self.email_entry.configure(state="disabled")
        self.send_code_button.configure(state="disabled")
        # Show verification code widgets
        self.verification_code_label.grid()
        self.verification_code_entry.grid()
        self.verify_code_button.grid()

    def verify_code(self):
        code = self.email_entered_code.get()
        email_receiver = self.email.get()
        msg = f"VRFYC|{email_receiver}|{code}"
        if len(msg) <= 60000:  # the size field is two bytes
            self.PROTO.send_one_message(msg.encode())
        else:
            showinfo(title="Information", message="At least ONE fields is too long!!")

    def process_verify_code(self, data):
        showinfo(title="Information", message=data)
        self.verification_code_label.grid_remove()
        self.verification_code_entry.grid_remove()
        self.verify_code_button.grid_remove()

        # Show update password widgets
        self.new_password_label.grid()
        self.new_password_entry.grid()
        self.confirm_password_label.grid()
        self.confirm_password_entry.grid()
        self.change_password_button.grid()

    def update_user_password(self):
        new_pass = self.new_password.get()
        confirm_pass = self.confirm_new_password.get()
        email_receiver = self.email.get()
        msg = f"UPDTE|{email_receiver}|{new_pass}|{confirm_pass}"
        if len(msg) <= 60000:  # the size field is two bytes
            self.PROTO.send_one_message(msg.encode())
        else:
            showinfo(title="Information", message="At least ONE fields is too long!!")

    def process_update_user_password(self, data):
        showinfo(title="Information", message=data)

        # Hide password update widgets
        self.new_password_label.grid_remove()
        self.new_password_entry.grid_remove()
        self.confirm_password_label.grid_remove()
        self.confirm_password_entry.grid_remove()
        self.change_password_button.grid_remove()

        self.notebook.set("Login")

    def clear_forgot_password(self):
        """ Resets all fields and hides verification/update widgets """
        self.email.set("")
        self.email_entered_code.set("")
        self.new_password.set("")
        self.confirm_new_password.set("")

        self.verification_code_label.grid_remove()
        self.verification_code_entry.grid_remove()
        self.verify_code_button.grid_remove()

        self.new_password_label.grid_remove()
        self.new_password_entry.grid_remove()
        self.confirm_password_label.grid_remove()
        self.confirm_password_entry.grid_remove()
        self.change_password_button.grid_remove()

        self.email_entry.configure(state="normal")
        self.send_code_button.configure(state="normal")

    def clear(self):
        self.username.set("")
        self.password.set("")
        self.email.set("")
        self.validate_password.set("")

        self.clear_forgot_password()  # reuse reset logic

    def create_thread(self, func_name):
        """ for each function the client side is making a thread """
        func = self.function_dict[func_name]
        t = threading.Thread(target=func, args=())
        t.start()

    def set_window(self):
        """ set the general client interface"""
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.window = ctk.CTk()
        self.window.geometry("600x500")
        self.window.title("Shesh-Besh System")

        self.set_encryption_selection_page()

    def set_encryption_selection_page(self):
        """ page for choosing encryption method """
        self.encryption_selection_frame = ctk.CTkFrame(self.window)
        self.encryption_selection_frame.pack(expand=True)

        # Title label
        title = ctk.CTkLabel(self.encryption_selection_frame, text="Select Encryption Method", font=("Arial", 18))
        title.pack(pady=20)

        # Variable for the encryption method
        self.encryption_method = ctk.StringVar(value="DH")  # Default is Diffie-Hellman

        # Diffie-Hellman radio button
        dh_radio = ctk.CTkRadioButton(
            self.encryption_selection_frame, text="Diffie-Hellman", variable=self.encryption_method, value="DH")
        dh_radio.pack(pady=10)

        # RSA radio button
        rsa_radio = ctk.CTkRadioButton(
            self.encryption_selection_frame, text="RSA", variable=self.encryption_method, value="RSA")
        rsa_radio.pack(pady=10)

        # Continue button; upon click, proceed to the login page
        continue_button = ctk.CTkButton(
            self.encryption_selection_frame,
            text="Continue",
            command=self.encryption_selected
        )
        continue_button.pack(pady=20)

    def encryption_selected(self):
        """ setting the encryption between client and server"""
        prot_to_use = self.encryption_method.get()
        self.PROTO.send_first_proto_message(prot_to_use)
        ans = self.PROTO.recv_one_message(encryption=False)
        try:
            query, value = ans.split(b"|")
            if query == "ERR02":
                showinfo(title="Information", message="Server Doesn't support this method.")
            else:
                threading.Thread(target=self.start_encryption, args=(prot_to_use,), daemon=True).start()

                while not self.is_encrypted:
                    self.window.update()  # Process ALL events including Windows messages
                    time.sleep(0.1)  # Shorter sleep for better responsiveness

                if self.is_encrypted:
                    self.encryption_selection_frame.destroy()
                    self.set_environment()
                    threading.Thread(target=self.recv_loop, daemon=True).start()
        except Exception as e:
            self.Print(f"ERROR with encryption stage!: {e}", 50)

    def start_encryption(self, prot_to_use):
        if prot_to_use == "DH":
            self.contact_with_DH()
        else:
            self.contant_with_RSA()

    def contact_with_DH(self):
        """DH encryption method"""
        self.PROTO.create_DH_keys()
        msg = b"CRTDH|" + self.PROTO.get_dh_parameters()
        self.PROTO.send_one_message(msg, False)
        ans = self.PROTO.recv_one_message(encryption=False)
        query, value = ans.split(b"|")

        if value.decode() == "yes":
            msg = b"GTKEY|" + self.PROTO.get_public_key_dh()
            self.PROTO.send_one_message(msg, False)
            ans = self.PROTO.recv_one_message(encryption=False)
            query, srv_public_key = ans.split(b"|")
            self.PROTO.create_shared_key_dh(srv_public_key)
            self.is_encrypted = True

    def contant_with_RSA(self):
        """RSA encryption method"""
        msg = b"CRTKY"
        self.PROTO.send_one_message(msg, False)
        ans = self.PROTO.recv_one_message(encryption=False)
        query, value = ans.split(b"|")  # query = GETKY
        if query == b"GETKY":
            self.PROTO.set_RSA_public_key(value)
            msg = b"GETKY|" + self.PROTO.encrypt_AES_key_by_RSA_public_key()
            self.PROTO.send_one_message(msg, False)
            bin_data = self.PROTO.recv_one_message()
            self.is_encrypted = True

    def set_environment(self):
        """ set the main pages """
        # Create Tab System (using pack for the notebook is OK)
        self.notebook = ctk.CTkTabview(self.window)
        self.notebook.pack(pady=20, expand=True, fill="both")

        self.login_tab = self.notebook.add("Login")
        self.signup_tab = self.notebook.add("Sign Up")
        self.forgot_password_tab = self.notebook.add("Forgot my password")

        self.username = ctk.StringVar()
        self.password = ctk.StringVar()
        self.email = ctk.StringVar()
        self.validate_password = ctk.StringVar()
        self.email_verification_code = ctk.StringVar()
        self.email_entered_code = ctk.StringVar()
        self.new_password = ctk.StringVar()
        self.confirm_new_password = ctk.StringVar()
        self.generated_code = ""

        self.set_login()
        self.set_signup()
        self.setup_forgot_password_tab()

    def set_login(self):
        # Use grid layout for the login tab
        self.login_tab.grid_columnconfigure(0, weight=1)
        self.login_tab.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(self.login_tab, text="Username:").grid(row=0, column=0, pady=5, padx=5, sticky="e")
        ctk.CTkEntry(self.login_tab, textvariable=self.username).grid(row=0, column=1, pady=5, padx=5, sticky="w")

        ctk.CTkLabel(self.login_tab, text="Password:").grid(row=1, column=0, pady=5, padx=5, sticky="e")
        ctk.CTkEntry(self.login_tab, textvariable=self.password, show="*").grid(row=1, column=1, pady=5, padx=5,
                                                                                sticky="w")

        ctk.CTkButton(
            self.login_tab, text="Login", command=lambda: self.create_thread("Login")
        ).grid(row=2, column=0, columnspan=2, pady=10, padx=5)

    def set_signup(self):
        # Use grid layout for the signup tab
        self.signup_tab.grid_columnconfigure(0, weight=1)
        self.signup_tab.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(self.signup_tab, text="Username:").grid(row=0, column=0, pady=5, padx=5, sticky="e")
        ctk.CTkEntry(self.signup_tab, textvariable=self.username).grid(row=0, column=1, pady=5, padx=5, sticky="w")

        ctk.CTkLabel(self.signup_tab, text="Email Address:").grid(row=1, column=0, pady=5, padx=5, sticky="e")
        ctk.CTkEntry(self.signup_tab, textvariable=self.email, width=200).grid(row=1, column=1, pady=5, padx=5,
                                                                               sticky="w")

        ctk.CTkLabel(self.signup_tab, text="Password:").grid(row=2, column=0, pady=5, padx=5, sticky="e")
        ctk.CTkEntry(self.signup_tab, textvariable=self.password, show="*").grid(row=2, column=1, pady=5, padx=5,
                                                                                 sticky="w")

        ctk.CTkLabel(self.signup_tab, text="Validate Password:").grid(row=3, column=0, pady=5, padx=5, sticky="e")
        ctk.CTkEntry(self.signup_tab, textvariable=self.validate_password, show="*").grid(row=3, column=1, pady=5,
                                                                                          padx=5, sticky="w")

        ctk.CTkButton(
            self.signup_tab, text="Sign Up", command=lambda: self.create_thread("Sign up")
        ).grid(row=4, column=0, columnspan=2, pady=10, padx=5)

    def setup_forgot_password_tab(self):
        """ Configures the Forgot Password Tab using grid layout """
        self.forgot_password_tab.grid_columnconfigure(0, weight=1)
        self.forgot_password_tab.grid_columnconfigure(1, weight=1)

        row = 0

        # Email Label & Entry
        self.email_label = ctk.CTkLabel(self.forgot_password_tab, text="Enter your email OR username:")
        self.email_label.grid(row=row, column=0, pady=5, padx=5, sticky="e")

        self.email_entry = ctk.CTkEntry(self.forgot_password_tab, textvariable=self.email, width=200)
        self.email_entry.grid(row=row, column=1, pady=5, padx=5, sticky="w")
        row += 1

        # Send Verification Code button
        self.send_code_button = ctk.CTkButton(
            self.forgot_password_tab, text="Send Verification Code",
            command=lambda: self.create_thread("Get verification code")
        )
        self.send_code_button.grid(row=row, column=0, columnspan=2, pady=10, padx=5)
        row += 1

        # Verification Code Section (Initially Hidden)
        self.verification_code_label = ctk.CTkLabel(self.forgot_password_tab, text="Enter Verification Code:")
        self.verification_code_entry = ctk.CTkEntry(self.forgot_password_tab, textvariable=self.email_entered_code)
        self.verify_code_button = ctk.CTkButton(
            self.forgot_password_tab, text="Verify Code", command=lambda: self.create_thread("Verify code")
        )

        self.verification_code_label.grid(row=row, column=0, pady=5, padx=5, sticky="e")
        self.verification_code_entry.grid(row=row, column=1, pady=5, padx=5, sticky="w")
        row += 1
        self.verify_code_button.grid(row=row, column=0, columnspan=2, pady=10, padx=5)
        row += 1

        # Initially hide verification code widgets
        self.verification_code_label.grid_remove()
        self.verification_code_entry.grid_remove()
        self.verify_code_button.grid_remove()

        # Update Password Section (Initially Hidden)
        self.new_password_label = ctk.CTkLabel(self.forgot_password_tab, text="New Password:")
        self.new_password_entry = ctk.CTkEntry(self.forgot_password_tab, textvariable=self.new_password, show="*")

        self.confirm_password_label = ctk.CTkLabel(self.forgot_password_tab, text="Confirm New Password:")
        self.confirm_password_entry = ctk.CTkEntry(self.forgot_password_tab, textvariable=self.confirm_new_password,
                                                   show="*")

        self.change_password_button = ctk.CTkButton(
            self.forgot_password_tab, text="Change My Password",
            command=lambda: self.create_thread("Update password")
        )

        self.new_password_label.grid(row=row, column=0, pady=5, padx=5, sticky="e")
        self.new_password_entry.grid(row=row, column=1, pady=5, padx=5, sticky="w")
        row += 1
        self.confirm_password_label.grid(row=row, column=0, pady=5, padx=5, sticky="e")
        self.confirm_password_entry.grid(row=row, column=1, pady=5, padx=5, sticky="w")
        row += 1
        self.change_password_button.grid(row=row, column=0, columnspan=2, pady=10, padx=5)
        row += 1

        # Initially hide password change widgets
        self.new_password_label.grid_remove()
        self.new_password_entry.grid_remove()
        self.confirm_password_label.grid_remove()
        self.confirm_password_entry.grid_remove()
        self.change_password_button.grid_remove()

        # Clear Button
        self.clear_button = ctk.CTkButton(
            self.forgot_password_tab, text="Clear", command=self.clear_forgot_password
        )
        self.clear_button.grid(row=row, column=0, columnspan=2, pady=20, padx=5)

    # adding

    def until_game_tab(self):
        """ Page shown after successful login, before game starts """
        # Destroy the notebook (tab system)
        self.notebook.destroy()

        self.until_game_frame = ctk.CTkFrame(self.window)
        self.until_game_frame.pack(expand=True, fill="both")

        welcome_msg = f"Welcome, {self.username_for_game}!"
        ctk.CTkLabel(self.until_game_frame, text=welcome_msg, font=("Arial", 22)).pack(pady=10)

        # Load and display the dice image (you uploaded it as icon.png)
        dice_image = ctk.CTkImage(light_image=Image.open("Images/icon.png"), size=(200, 200))
        ctk.CTkLabel(self.until_game_frame, image=dice_image, text="").pack(pady=10)

        # Start Game Button
        ctk.CTkButton(
            self.until_game_frame,
            text="START GAME!",
            font=("Arial", 18),
            command=self.start_lobby
        ).pack(pady=15)

        # Logout Button
        ctk.CTkButton(
            self.until_game_frame,
            text="Logout",
            command=self.logout
        ).pack(pady=5)

    def start_lobby(self):
        msg = "READY|start".encode()
        self.ready_for_game = True
        self.PROTO.send_one_message(msg)

    def process_start_lobby(self, data):  # will get LISTD
        self.waiting_room_tab()

    def cancel_game(self):
        msg = "CANCL|cancel".encode()
        self.PROTO.send_one_message(msg)

    def process_cancel(self, data):
        # Stop animation before switching frames
        self.stop_gif_animation()

        def safe_return():
            try:
                self.return_to_until_game()
            except tk.TclError:
                # Fallback: just recreate the until_game_tab
                self.until_game_tab()

        self.window.after(100, safe_return)  # Small delay to let events process

    def logout(self):
        msg = "LGOUT|logout".encode()
        self.PROTO.send_one_message(msg)

    def process_logout(self, data):
        """Handle server logout confirmation."""

        def safe_logout():
            try:
                self.ready_for_game = False
                self.animating = False  # stop GIF animation if any

                if hasattr(self, 'until_game_frame') and self.until_game_frame.winfo_exists():
                    self.until_game_frame.destroy()

                self.set_environment()
            except Exception as e:
                self.Print(f"Logout UI error: {e}", 50)

        self.window.after(0, safe_logout)

    def waiting_room_tab(self):
        # Stop any existing animation before creating new frame
        self.stop_gif_animation()

        # Destroy previous frame safely
        if hasattr(self, 'until_game_frame'):
            try:
                if self.until_game_frame.winfo_exists():
                    self.until_game_frame.destroy()
            except tk.TclError:
                pass  # Frame already destroyed

        self.waiting_frame = ctk.CTkFrame(self.window)
        self.waiting_frame.pack(expand=True, fill="both")

        # Create loading label
        loading_label = ctk.CTkLabel(self.waiting_frame, text="Finding opponent...")
        loading_label.pack(pady=10)

        # Prepare animated GIF display
        self.gif_label = ctk.CTkLabel(self.waiting_frame, text="")
        self.gif_label.pack(pady=20)

        # Load and start the animated GIF
        self.load_animated_gif("Images/loading.gif")

        # Cancel Button
        ctk.CTkButton(self.waiting_frame, text="Cancel", command=self.cancel_game).pack(pady=10)

    def load_animated_gif(self, path):
        """Load and animate a GIF file"""
        try:
            # Stop any existing animation
            self.stop_gif_animation()
            # Clear previous frames
            self.gif_frames = []
            # Load the GIF
            gif = Image.open(path)
            # Extract all frames
            frame_index = 0
            while True:
                try:
                    gif.seek(frame_index)
                    frame = gif.copy()
                    # Resize the frame
                    resized_frame = frame.resize((200, 200))  # Adjust size as needed
                    # Convert to CTkImage
                    ct_image = CTkImage(light_image=resized_frame, size=(200, 200))
                    self.gif_frames.append(ct_image)
                    frame_index += 1
                except EOFError:
                    # End of frames
                    break
            if self.gif_frames:
                self.gif_frame_index = 0
                self.animating = True
                self.animate_gif_frame()
        except Exception as e:
            self.Print(f"Exception at loading the gif: {e}", 40)

    def animate_gif_frame(self):
        """Animate the GIF frames"""
        try:
            # Check if we should continue animating
            if (not self.animating or
                    not hasattr(self, 'gif_label') or
                    not self.gif_frames):
                return

            # Check if the label still exists
            if not self.gif_label.winfo_exists():
                self.animating = False
                return

            # Update the frame
            current_frame = self.gif_frames[self.gif_frame_index]
            self.gif_label.configure(image=current_frame)
            self.gif_label.image = current_frame  # Keep a reference

            # Move to next frame
            self.gif_frame_index = (self.gif_frame_index + 1) % len(self.gif_frames)

            # Schedule next frame update (100ms delay = ~10 FPS)
            if self.animating:
                self.animation_job = self.window.after(100, self.animate_gif_frame)

        except (tk.TclError, AttributeError) as e:
            # Widget was destroyed or doesn't exist
            self.animating = False
            self.animation_job = None

    def stop_gif_animation(self):
        """Stop the GIF animation cleanly"""
        self.animating = False

        # Cancel any pending animation job
        if self.animation_job is not None:
            try:
                self.window.after_cancel(self.animation_job)
            except tk.TclError:
                pass  # Already cancelled or window destroyed
            finally:
                self.animation_job = None

    def return_to_until_game(self):
        def safe_switch():
            try:
                if hasattr(self, 'waiting_frame') and self.waiting_frame.winfo_exists():
                    # Process pending events before destroying
                    self.waiting_frame.update_idletasks()
                    self.waiting_frame.destroy()
                self.until_game_tab()
            except tk.TclError:
                # If there's still an error, just proceed with creating the new tab
                self.until_game_tab()

        self.window.after(0, safe_switch)

    def process_func(self, data):
        func = Func.from_str(data)
        if func.subject == "MATCH":
            self.start_match(func)
        else:
            while self.game is None:
                time.sleep(0.5)
            self.game.process_func(func)

    def start_match(self, func):
        # Hide the Tkinter window
        self.window.withdraw()

        # Launch Pygame in a thread
        def launch_game():
            try:
                self.game = game_class.Game(
                    player_color=func.color, player_username=self.username_for_game, opponent_username=func.opponent,
                    PROTO=self.PROTO, logging_level=self.logging_level, turn=func.turn)
                self.game.run()
            finally:
                self.window.after(0, self.show_main_and_tab)

        threading.Thread(target=launch_game, daemon=True).start()

    def show_main_and_tab(self):  # show tkinter after the game window closes
        self.window.deiconify()  # un-hide
        self.window.lift()  # bring to front
        self.window.focus_force()  # catch the focus of the window
        self.cleanup_game_related_frames()  # to avoid mashup with tabs when getting back.
        self.until_game_tab()

    def cleanup_game_related_frames(self):
        """Clean up only game-related frames to prevent mashup"""
        frames_to_cleanup = ('waiting_frame', 'until_game_frame')

        for frame_name in frames_to_cleanup:
            if hasattr(self, frame_name):
                frame = getattr(self, frame_name)
                try:
                    if frame and frame.winfo_exists():
                        # Force update to process any pending events before destroying
                        frame.update_idletasks()
                        frame.destroy()
                except tk.TclError:
                    pass  # Frame already destroyed
