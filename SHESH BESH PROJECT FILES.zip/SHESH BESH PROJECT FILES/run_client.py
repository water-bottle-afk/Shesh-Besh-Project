__author__ = "Nadav"

from classes import UDPClient
from client_class import Client
import tkinter as tk

# MONEY PATCH - trying to override the tclErrors from tkinter
original_canvas_delete = tk.Canvas.delete

def safe_canvas_delete(self, *args):
    try:
        # perform deleting
        return original_canvas_delete(self, *args)
    except tk.TclError:
        pass


# Replace the method globally
tk.Canvas.delete = safe_canvas_delete

logging_level = 10
UDP_PORT = 57071

udp_cln = UDPClient(UDP_PORT, logging_level)
tcp_ip, tcp_port = udp_cln.run()

# run actual client
cln = Client(tcp_ip, tcp_port, logging_level)
